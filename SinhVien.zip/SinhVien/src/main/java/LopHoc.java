

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class LopHoc extends DBSV
{
    /**
     * Lấy ra nhiều dòng bản ghi dữ liệu
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static List<HashMap<String, String>> List() 
            throws SQLException, ClassNotFoundException
    {
        String sql = 
            "SELECT \n" +
                "`maLopHoc`, \n" + 
                "`tenLopHoc`,\n" +
                "`namTaoLop`\n" +
                
            " FROM `lophoc`";
        
        DBSV.open(); // Mở kết nối tới CSDL
        ResultSet rs = DBSV.q(sql);
            
        // Dữ liệu trả về
        List<HashMap<String,String>> list = new ArrayList<>();
        
        // Đẩy dữ liệu bảng MySQL sang Java List
        while(rs.next())
        {
            HashMap<String,String> row = new HashMap<>();
            
            row.put("maLopHoc", rs.getString("maLopHoc")) ;
            row.put("tenLopHoc",       rs.getString("tenLopHoc")) ;
            row.put("namTaoLop",      rs.getString("namTaoLop")) ;
            
                
            list.add(row);             
        }
        
        DBSV.close(); // Đóng kết nối sau khi dữ liệu ResultSet đã chạy sang List
                    // Khi đóng DB thì ResultSet cũng chết theo !!!
        
        return list;
    }
    
    /**
     * Lấy ra chi tiết của 1 dòng bản ghi dữ liệu
     * @param id
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static HashMap<String,String> Details(String id) 
            throws SQLException, ClassNotFoundException
    {
        //String sql = "SELECT * FROM `LopHoc` ");
        String sql = "SELECT \n" +
                "`maLopHoc`, \n" +
                "`tenLopHoc`, \n" +
                "`namTaoLop`,\n" +
                
                "FROM `lophoc`\n" +
                    "WHERE `maLopHoc`='"+id+"'";
        
        DBSV.open(); // Mở kết nối tới CSDL
        ResultSet rs = DBSV.q(sql);
            
        // Dữ liệu trả về
        HashMap<String,String> row  = new HashMap<>();
        
        // Đẩy dữ liệu bảng MySQL sang Java List
        while(rs.next())
        {
         
            row.put("maLopHoc", rs.getString("maLopHoc")) ;
            row.put("tenLopHoc",       rs.getString("tenLopHoc")) ;
            row.put("namTaoLop",      rs.getString("namTaoLop")) ;
            
                
            break; // Lấy xong dữ liệu 1 dòng bản ghi rồi thì thôi        
        }
        
        DBSV.close(); // Đóng kết nối sau khi dữ liệu ResultSet đã chạy sang List
                    // Khi đóng DB thì ResultSet cũng chết theo !!!
        
        return row;
    }
    
    /**
     * Thêm mới 1 dòng bản ghi
     * @param params
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static void AddLop(HashMap<Integer,String> params) 
            throws SQLException, ClassNotFoundException
    {
       
            
        // the mysql insert statement
        // Đừng có đặt dấu ? trong nháy đơn, Java làm hộ mình rồi nhé !
        String sql = " INSERT INTO lophoc "
                   + " SET `maLopHoc` =?, " 
                   + "`tenLopHoc`=?, "
                   + "`namTaoLop`=? ";
                  
                   
        DBSV.open();
        // Thực thi câu SQL INSERT
        DBSV.exec(sql, params);
        DBSV.close();
    }
    
    /**
     * Sửa 1 dòng bản ghi theo khoá chính: id
     * @param params
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static void Edit(HashMap<Integer,String> params) 
            throws SQLException, ClassNotFoundException
    {
        
            
        // the mysql insert statement
        // Đừng có đặt dấu ? trong nháy đơn, Java làm hộ mình rồi nhé !
        // Đừng có đặt dấu ? trong nháy đơn, Java làm hộ mình rồi nhé !
        String sql = " UPDATE lophoc "
                    + "SET `maLopHoc`=?,"
                    +     "`tenLopHoc`=?,"
                    +     "`namTaoLop`=?,"
                 
                    + " WHERE `maLopHoc` = ?";
                       
        // Thực thi câu SQL UPDATE
        DBSV.exec(sql, params);
    }
    
    /**
     * Xoá 1 dòng bản ghi theo khoá chính id
     * @param params
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static void Delete(HashMap<Integer,String> params) 
            throws SQLException, ClassNotFoundException
    {
        // Câu này paste trực tiếp vào XAMPP PHP MySQL lại ko việc gì 
            //INSERT INTO ThuCung SET `Ten`='Doremon',`Tuoi`='3',`CanNang`='3.5',`NhomMau`='A',`GioiTinh`= '1'
            
        // the mysql insert statement
        // Đừng có đặt dấu ? trong nháy đơn, Java làm hộ mình rồi nhé !
        // Đừng có đặt dấu ? trong nháy đơn, Java làm hộ mình rồi nhé !
        // Câu này paste trực tiếp vào XAMPP PHP MySQL lại ko việc gì 
            //INSERT INTO ThuCung SET `Ten`='Doremon',`NamSinh`='2001',`CanNang`='3.5',`NhomMau`='A',`GioiTinh`= '1'
            

        String sql = " DELETE FROM `lophoc` WHERE `maLopHoc` = ?";
                       
        // Thực thi câu SQL 
        DBSV.exec(sql, params);
    }
}// end class
