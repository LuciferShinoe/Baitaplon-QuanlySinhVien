
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class SinhVien extends DBSV
{
    /**
     * Lấy ra nhiều dòng bản ghi dữ liệu
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static List<HashMap<String, String>> List() 
            throws SQLException, ClassNotFoundException
    {
        String sql = 
            "SELECT \n" +
                "`MaSV`, \n" +
                "`maLopHoc`,\n" +
                "`Ten`,\n" +
                "`NamSinh`,\n" +
                "`CanNang`,\n" +
                "`NhomMau`,\n" +
                "`GioiTinh`,\n" +
                "IF(GioiTinh=1, 'Nam', 'Nữ') AS `GioiTinh_text`\n" +
            "FROM `sinhvien`";
        
        DBSV.open(); // Mở kết nối tới CSDL
        ResultSet rs = DBSV.q(sql);
            
        // Dữ liệu trả về
        List<HashMap<String,String>> list = new ArrayList<>();
        
        // Đẩy dữ liệu bảng MySQL sang Java List
        while(rs.next())
        {
            HashMap<String,String> row = new HashMap<>();
            row.put("MaSV", rs.getString("MaSV")) ;
            row.put("maLopHoc", rs.getString("maLopHoc")) ;
            row.put("Ten",       rs.getString("Ten")) ;
            row.put("NamSinh",      rs.getString("NamSinh")) ;
            row.put("CanNang",   rs.getString("CanNang")) ;
            row.put("NhomMau",   rs.getString("NhomMau")) ;
            row.put("GioiTinh",  rs.getString("GioiTinh")) ;
            row.put("GioiTinh_text", rs.getString("GioiTinh_text")) ;
                
            list.add(row);             
        }
        
        DBSV.close(); // Đóng kết nối sau khi dữ liệu ResultSet đã chạy sang List
                    // Khi đóng DB thì ResultSet cũng chết theo !!!
        
        return list;
    }
    
    /**
     * Lấy ra chi tiết của 1 dòng bản ghi dữ liệu
     * @param MaSV
     * @return
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static HashMap<String,String> Details(String MaSV) 
            throws SQLException, ClassNotFoundException
    {
        //String sql = "SELECT * FROM `SinhVien` ");
        String sql = "SELECT \n" +
                "`MaSV`, \n" +
                "`maLopHoc`, \n" +
                "`Ten`,\n" +
                "`NamSinh`,\n" +
                "`CanNang`,\n" +
                "`NhomMau`,\n" +
                "`GioiTinh`,\n" +
                "IF(GioiTinh=1, 'Nam', 'Nữ') AS `GioiTinh_text`\n" +
                "FROM `sinhvien`\n" +
                    "WHERE `MaSV`='"+MaSV+"'";
        
        DBSV.open(); // Mở kết nối tới CSDL
        ResultSet rs = DBSV.q(sql);
            
        // Dữ liệu trả về
        HashMap<String,String> row  = new HashMap<>();
        
        // Đẩy dữ liệu bảng MySQL sang Java List
        while(rs.next())
        {
            row.put("MaSV", rs.getString("MaSV")) ;
            row.put("maLopHoc", rs.getString("maLopHoc")) ;
            row.put("Ten",       rs.getString("Ten")) ;
            row.put("NamSinh",      rs.getString("NamSinh")) ;
            row.put("CanNang",   rs.getString("CanNang")) ;
            row.put("NhomMau",   rs.getString("NhomMau")) ;
            row.put("GioiTinh",  rs.getString("GioiTinh")) ;
            row.put("GioiTinh_text", rs.getString("GioiTinh_text")) ;
                
            break; // Lấy xong dữ liệu 1 dòng bản ghi rồi thì thôi        
        }
        
        
        DBSV.close(); // Đóng kết nối sau khi dữ liệu ResultSet đã chạy sang List
                    // Khi đóng DB thì ResultSet cũng chết theo !!!
        
        return row;
    }
    
    /**
     * Thêm mới 1 dòng bản ghi
     * @param params
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static void Add(HashMap<Integer,String> params) 
            throws SQLException, ClassNotFoundException
    {
       
            
        // the mysql insert statement
        // Đừng có đặt dấu ? trong nháy đơn, Java làm hộ mình rồi nhé !
        String sql = " INSERT INTO sinhvien "
                   + " SET `maLopHoc` =?, " 
                   + "`Ten`=?, "
                   + "`NamSinh`=?, "
                   + "`CanNang`=?, "
                   + "`NhomMau`=?, "
                   + "`GioiTinh`= b?";
                       
        // Thực thi câu SQL INSERT
        DBSV.open();
        DBSV.exec(sql, params);
        DBSV.close();
    }
    
    /**
     * Sửa 1 dòng bản ghi theo khoá chính: MaSV
     * @param params
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static void Edit(HashMap<Integer,String> params) 
            throws SQLException, ClassNotFoundException
    {
        
        String sql = " UPDATE sinhvien "
                    + "SET `Ten`=?,"
                    +     "`NamSinh`=?,"
                    +     "`CanNang`=?,"
                    +     "`NhomMau`=?,"
                    +     "`GioiTinh`=?"
                    + " WHERE `MaSV` = ?";
                       
        // Thực thi câu SQL UPDATE
        DBSV.open();
        DBSV.exec(sql, params);
        DBSV.close();
    }
    
    /**
     * Xoá 1 dòng bản ghi theo khoá chính MaSV
     * @param params
     * @throws SQLException
     * @throws ClassNotFoundException 
     */
    public static void Delete(HashMap<Integer,String> params) 
            throws SQLException, ClassNotFoundException
    {
        // Câu này paste trực tiếp vào XAMPP PHP MySQL lại ko việc gì 
            //INSERT INTO ThuCung SET `Ten`='Doremon',`Tuoi`='3',`CanNang`='3.5',`NhomMau`='A',`GioiTinh`= '1'
            
        // the mysql insert statement
        // Đừng có đặt dấu ? trong nháy đơn, Java làm hộ mình rồi nhé !
        // Đừng có đặt dấu ? trong nháy đơn, Java làm hộ mình rồi nhé !
        // Câu này paste trực tiếp vào XAMPP PHP MySQL lại ko việc gì 
            //INSERT INTO ThuCung SET `Ten`='Doremon',`NamSinh`='2001',`CanNang`='3.5',`NhomMau`='A',`GioiTinh`= '1'
            

        String sql = " DELETE FROM `sinhvien` WHERE `MaSV` = ?";
                       
        // Thực thi câu SQL 
        DBSV.exec(sql, params);
    }
    
    // lay danh sach ma lop hoc
    public static List<String> getClassIDList()throws SQLException, ClassNotFoundException{
    	List<String> list = new ArrayList();
    	String sql = "SELECT * FROM lophoc";
    	DBSV.open();
    	
    	ResultSet rs = DBSV.q(sql);
    	
    	while(rs.next()) {
    		list.add(String.valueOf(rs.getInt("maLopHoc")));
    	}
    	
    	DBSV.close();
    	
    	return list;
    }
}// end class
