

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class addKetQuaThiServlet
 */
@WebServlet({ "/addKetQuaThi", "/themKetQuaThi" })
public class addKetQuaThiServlet extends HttpServlet {

       

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * Processes requests for both HTTP <code>GE9T</code> and <code>POST</code>
	 * methods.
	 *
	 * @param request  servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException      if an I/O error occurs
	 */
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			/* TODO output your page here. You may use following sample code. */
			out.println("<!DOCTYPE html>");
			out.println("<html>");
			out.println("<head>");
			out.println("<title>Servlet AddKetQuaThiServlet</title>");
			out.println("</head>");
			out.println("<body>");
			out.println("<h1>Servlet AddLopServlet at " + request.getContextPath() + "</h1>");
			out.println("</body>");
			out.println("</html>");
		}
	}

	// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the
	// + sign on the left to edit the code.">
	/**
	 * Handles the HTTP <code>GET</code> method.
	 *
	 * @param request  servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException      if an I/O error occurs
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// processRequest(request, response);
//        if (request.getCharacterEncoding() == null) {
//            request.setCharacterEncoding("utf-8");
//           }
//           response.setContentType("text/json; charset=UTF-8");
//           PrintWriter out = response.getWriter();
//           String raw = request.getParameter("q");
//           if (raw == null || "".equals(raw)) {
//            out.println("{ok:false, entailments:[], triples=[], msg=\"\"}");
//           } else {
//            doGet(out, raw);
//           }
//           out.close();
		
		// lay danh sach ma lop hoc
				try {
					List<String> danhSachMaLopHoc = SinhVien.getClassIDList();
					request.setAttribute("danhSachMaLopHoc", danhSachMaLopHoc);
				} catch (ClassNotFoundException | SQLException e) {
					System.out.println("Khong the lay danh sach ma lop hoc");
					e.getMessage();
				}
				// lay danh sach ma sinh vien
				try {
					List<String> danhSachMaSV = SinhVien.getClassIDList();
					request.setAttribute("danhSachMaSV", danhSachMaSV);
				} catch (ClassNotFoundException | SQLException e) {
					System.out.println("Khong the lay danh sach ma sinh vien");
					e.getMessage();
				}
				// lay danh sach ma mon hoc
				try {
					List<String> danhSachMaMonHoc = SinhVien.getClassIDList();
					request.setAttribute("danhSachMaMonHoc", danhSachMaMonHoc);
				} catch (ClassNotFoundException | SQLException e) {
					System.out.println("Khong the lay danh sach ma lop hoc");
					e.getMessage();
				}
		

		request.setAttribute("web_title", "Thêm Mới Kết quả thi "); // Tựa đề Web
		request.setAttribute("web_content", "addKetQuaThi.jsp"); // Nội dung Web

		try {
			request.getRequestDispatcher("/WEB-INF/jsp/layout.jsp").forward(request, response);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	/**
	 * Handles the HTTP <code>POST</code> method.
	 *
	 * @param request  servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException      if an I/O error occurs
	 *                          https://stackoverflow.com/questions/4971877/how-to-transfer-data-from-jsp-to-servlet-when-submitting-html-form
	 *                          https://ofstack.com/Java/7547/a-java-utility-class-that-connects-to-a-mysql-database.html
	 *                          https://www.vogella.com/tutorials/MySQLJava/article.html
	 *                          https://ict.iitk.ac.in/forum/topic/java-sql-sqlexception-parameter-index-out-of-range-1-number-of-parameters-which-is-0/
	 *                          https://alvinalexander.com/java/java-mysql-insert-example-preparedstatement/
	 *                          https://www.tabnine.com/code/java/methods/javax.servlet.http.HttpServletRequest/setCharacterEncoding
	 *                          https://stackoverflow.com/questions/16527576/httpservletrequest-utf-8-encoding
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Chỉ rõ lược đồ mã hoá font chữ, trước khi
		// lưu dữ liệu Form vào SQL
		request.setCharacterEncoding("UTF-8");

		try {
			// Bắt lấy dữ liệu gửi lên từ Form
			
			String MaSV = request.getParameter("MaSV");
			String maLopHoc = request.getParameter("maLopHoc");
			String maMonHoc = request.getParameter("maMonHoc");
			String Diem = request.getParameter("Diem");
			

			HashMap<Integer, String> data = new HashMap<>();
			data.put(1, MaSV);
			data.put(2, maLopHoc);
			data.put(3, maMonHoc);
			data.put(4, Diem);
			
			// Thêm mới dòng bản ghi vào CSDL 
			KetQuaThi.AddLop(data);

			HttpSession session = request.getSession();
			session.setAttribute("SUCCESS_MSG", "Đã hoàn tất việc thêm mới !");

			response.sendRedirect("/SinhVien/listKetQuaThi");
		} catch (Exception ex) {

			System.out.println("SQL Error est: " + ex.getMessage());
			ex.printStackTrace();

		}

		processRequest(request, response);
	}

	/**
	 * Returns a short description of the servlet.
	 *
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Short description";
	}
}

